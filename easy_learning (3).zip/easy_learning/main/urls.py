from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('courses/', views.browse_courses, name='browse_courses'),
    path('courses/<int:course_id>/', views.course_detail, name='course_detail'),
    path('courses/<int:course_id>/enroll/', views.enroll_course, name='enroll_course'),
    path('payment/success/', views.payment_success, name='payment_success'),
    path('payment/cancel/', views.payment_cancel, name='payment_cancel'),
]

urlpatterns = [
    # ... existing URLs
    path('dashboard/', views.dashboard, name='dashboard'),
    path('dashboard/course/<int:enrollment_id>/', views.course_progress, name='course_progress'),
]
