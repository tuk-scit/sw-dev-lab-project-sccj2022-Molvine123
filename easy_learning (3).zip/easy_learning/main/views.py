from django.shortcuts import render, get_object_or_404
from .models import Course, Category, SubCategory
from django.db.models import Q

def browse_courses(request):
    categories = Category.objects.all()
    courses = Course.objects.all()

    query = request.GET.get('q')
    category = request.GET.get('category')
    subcategory = request.GET.get('subcategory')
    price = request.GET.get('price')

    if query:
        courses = courses.filter(Q(title__icontains=query) | Q(description__icontains=query))

    if category:
        courses = courses.filter(category__id=category)

    if subcategory:
        courses = courses.filter(subcategory__id=subcategory)

    if price:
        if price == 'free':
            courses = courses.filter(price=0)
        elif price == 'paid':
            courses = courses.exclude(price=0)

    context = {
        'categories': categories,
        'courses': courses,
    }
    return render(request, 'main/browse_courses.html', context)

def course_detail(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    return render(request, 'main/course_detail.html', {'course': course})

import stripe
from django.conf import settings
from django.shortcuts import redirect
from django.urls import reverse
from .models import Course, Enrollment

stripe.api_key = settings.STRIPE_SECRET_KEY

def enroll_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.method == 'POST':
        # Create Stripe Checkout Session
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': course.title,
                    },
                    'unit_amount': int(course.price * 100),  # Amount in cents
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=request.build_absolute_uri(reverse('payment_success')) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.build_absolute_uri(reverse('payment_cancel')),
            metadata={
                'user_id': request.user.id,
                'course_id': course.id,
            }
        )
        return redirect(session.url, code=303)
    else:
        return render(request, 'main/enroll_course.html', {'course': course, 'stripe_public_key': settings.STRIPE_PUBLIC_KEY})

import stripe
from django.conf import settings
from django.shortcuts import redirect
from django.urls import reverse
from .models import Course, Enrollment

stripe.api_key = settings.STRIPE_SECRET_KEY

def enroll_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    if request.method == 'POST':
        # Create Stripe Checkout Session
        session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=[{
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': course.title,
                    },
                    'unit_amount': int(course.price * 100),  # Amount in cents
                },
                'quantity': 1,
            }],
            mode='payment',
            success_url=request.build_absolute_uri(reverse('payment_success')) + '?session_id={CHECKOUT_SESSION_ID}',
            cancel_url=request.build_absolute_uri(reverse('payment_cancel')),
            metadata={
                'user_id': request.user.id,
                'course_id': course.id,
            }
        )
        return redirect(session.url, code=303)
    else:
        return render(request, 'main/enroll_course.html', {'course': course, 'stripe_public_key': settings.STRIPE_PUBLIC_KEY})

from django.contrib.auth.decorators import login_required

@login_required
def dashboard(request):
    enrollments = Enrollment.objects.filter(user=request.user)
    return render(request, 'main/dashboard.html', {'enrollments': enrollments})

@login_required
def course_progress(request, enrollment_id):
    enrollment = get_object_or_404(Enrollment, id=enrollment_id, user=request.user)
    # Logic to update and display progress
    return render(request, 'main/course_progress.html', {'enrollment': enrollment})
